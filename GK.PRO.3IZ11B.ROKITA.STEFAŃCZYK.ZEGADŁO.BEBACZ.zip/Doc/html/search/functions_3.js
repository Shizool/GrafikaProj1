var searchData=
[
  ['gamma_5fvaluechanged',['Gamma_ValueChanged',['../class_grafika_proj_1_1_main_window.html#a3e949c359663048bc3d28baab78111f0',1,'GrafikaProj::MainWindow']]],
  ['getcustomizedsource',['GetCustomizedSource',['../class_grafika_proj_1_1_image_customizator.html#a0935fd403698af0ed5cd681564f32a23',1,'GrafikaProj::ImageCustomizator']]]
];
