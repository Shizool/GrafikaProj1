var searchData=
[
  ['imagecustomizator',['ImageCustomizator',['../class_grafika_proj_1_1_image_customizator.html#a9dc6834aafa5c3039a7b465978259547',1,'GrafikaProj::ImageCustomizator']]]
];
