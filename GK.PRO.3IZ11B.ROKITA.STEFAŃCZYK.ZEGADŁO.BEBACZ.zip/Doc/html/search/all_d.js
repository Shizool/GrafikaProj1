var searchData=
[
  ['truncate',['Truncate',['../class_grafika_proj_1_1_image_customizator.html#abec25ea8e460fc27087af9a04f02a5d5',1,'GrafikaProj::ImageCustomizator']]]
];
