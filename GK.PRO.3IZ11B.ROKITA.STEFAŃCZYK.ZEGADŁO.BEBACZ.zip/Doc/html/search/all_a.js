var searchData=
[
  ['point',['Point',['../_main_window_8xaml_8cs.html#af7183cff3a6e75db2170da28384d7419',1,'MainWindow.xaml.cs']]],
  ['preparemaps',['prepareMaps',['../class_grafika_proj_1_1_image_customizator.html#aebbe7a12be72bdc6a983bb84d96bf2ec',1,'GrafikaProj::ImageCustomizator']]]
];
