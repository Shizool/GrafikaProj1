var searchData=
[
  ['brightnessmap',['brightnessMap',['../class_grafika_proj_1_1_image_customizator.html#acd26b1c687e2c00265dec2b927e57613',1,'GrafikaProj::ImageCustomizator']]]
];
