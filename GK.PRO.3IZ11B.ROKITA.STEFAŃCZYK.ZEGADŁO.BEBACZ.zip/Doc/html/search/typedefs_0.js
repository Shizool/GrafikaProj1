var searchData=
[
  ['lineseries',['LineSeries',['../_chart_window_8xaml_8cs.html#abc0f3aa5ac1426e6efed5f1fe467018b',1,'ChartWindow.xaml.cs']]]
];
