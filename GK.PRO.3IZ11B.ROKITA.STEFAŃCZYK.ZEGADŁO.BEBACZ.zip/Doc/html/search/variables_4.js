var searchData=
[
  ['gammamap',['gammaMap',['../class_grafika_proj_1_1_image_customizator.html#a5e36e80e5d2060ad43ada320af49954c',1,'GrafikaProj::ImageCustomizator']]]
];
