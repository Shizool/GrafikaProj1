var searchData=
[
  ['point',['Point',['../_main_window_8xaml_8cs.html#af7183cff3a6e75db2170da28384d7419',1,'MainWindow.xaml.cs']]]
];
