var searchData=
[
  ['_5fbrightness',['_brightness',['../class_grafika_proj_1_1_image_customizator.html#a707e2e0c8bccf20084b8f57939f14eff',1,'GrafikaProj::ImageCustomizator']]],
  ['_5fchartwindow',['_chartWindow',['../class_grafika_proj_1_1_image_customizator.html#a2c86cd312aba1f0c431edef0cc8b4f23',1,'GrafikaProj::ImageCustomizator']]],
  ['_5fcontrast',['_contrast',['../class_grafika_proj_1_1_image_customizator.html#a505b2dec94e23a2fdcf114789dbdb71f',1,'GrafikaProj::ImageCustomizator']]],
  ['_5fcustomizedbitmap',['_customizedBitmap',['../class_grafika_proj_1_1_image_customizator.html#aac8f2f701dfab0795a647e2937db0258',1,'GrafikaProj::ImageCustomizator']]],
  ['_5fgamma',['_gamma',['../class_grafika_proj_1_1_image_customizator.html#a62906e53ada3c6529eb7d512b88ffeb7',1,'GrafikaProj::ImageCustomizator']]],
  ['_5fimagecustomizator',['_imageCustomizator',['../class_grafika_proj_1_1_main_window.html#a82253cbf931b7474d0612bbb8406612a',1,'GrafikaProj::MainWindow']]],
  ['_5fsourcebitmap',['_sourceBitmap',['../class_grafika_proj_1_1_image_customizator.html#acc294901a465ae038fbac2f51e430698',1,'GrafikaProj::ImageCustomizator']]]
];
