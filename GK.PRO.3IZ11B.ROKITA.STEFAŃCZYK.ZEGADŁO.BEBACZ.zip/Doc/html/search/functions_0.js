var searchData=
[
  ['applydatatochart',['applyDataToChart',['../class_grafika_proj_1_1_chart_window.html#a2242be11c88280fc58cefc8dcf84bc7b',1,'GrafikaProj::ChartWindow']]],
  ['applyfilters',['ApplyFilters',['../class_grafika_proj_1_1_image_customizator.html#a42cae11963d0ea1c15fc61b2f057c2a9',1,'GrafikaProj::ImageCustomizator']]]
];
