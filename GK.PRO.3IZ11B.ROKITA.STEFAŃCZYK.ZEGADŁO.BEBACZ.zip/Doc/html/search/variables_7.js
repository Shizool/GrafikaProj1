var searchData=
[
  ['startmargin',['startMargin',['../class_grafika_proj_1_1_main_window.html#a41a4fdf85f2929739a00381022cfd252',1,'GrafikaProj::MainWindow']]],
  ['startpoint',['startPoint',['../class_grafika_proj_1_1_main_window.html#a8f69f3a3c8a976ea669d2cbbeff7acfa',1,'GrafikaProj::MainWindow']]]
];
