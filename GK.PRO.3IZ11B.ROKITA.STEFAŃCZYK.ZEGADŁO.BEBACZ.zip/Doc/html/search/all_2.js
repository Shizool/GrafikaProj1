var searchData=
[
  ['brightness_5fvaluechanged',['Brightness_ValueChanged',['../class_grafika_proj_1_1_main_window.html#a7d75ee46d529a9c3f8cba914bc6ce0c1',1,'GrafikaProj::MainWindow']]],
  ['brightnessmap',['brightnessMap',['../class_grafika_proj_1_1_image_customizator.html#acd26b1c687e2c00265dec2b927e57613',1,'GrafikaProj::ImageCustomizator']]],
  ['button_5fclick',['Button_Click',['../class_grafika_proj_1_1_main_window.html#a787e0f1c91e2c159b35271e5ff3b4ec6',1,'GrafikaProj::MainWindow']]]
];
