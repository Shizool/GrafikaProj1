var indexSectionsWithContent =
{
  0: "_abcegilmoprst",
  1: "acim",
  2: "g",
  3: "acim",
  4: "abcgilmoprst",
  5: "_bcegims",
  6: "lp"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs"
};

var indexSectionLabels =
{
  0: "Wszystko",
  1: "Klasy",
  2: "Przestrzenie nazw",
  3: "Pliki",
  4: "Funkcje",
  5: "Zmienne",
  6: "Definicje typów"
};

