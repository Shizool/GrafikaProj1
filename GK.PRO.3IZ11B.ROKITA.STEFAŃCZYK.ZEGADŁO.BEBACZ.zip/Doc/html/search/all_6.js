var searchData=
[
  ['imagecustomizator',['ImageCustomizator',['../class_grafika_proj_1_1_image_customizator.html',1,'GrafikaProj.ImageCustomizator'],['../class_grafika_proj_1_1_image_customizator.html#a9dc6834aafa5c3039a7b465978259547',1,'GrafikaProj.ImageCustomizator.ImageCustomizator()']]],
  ['imagecustomizator_2ecs',['ImageCustomizator.cs',['../_image_customizator_8cs.html',1,'']]],
  ['isselecting',['IsSelecting',['../class_grafika_proj_1_1_main_window.html#a17347592f302b3ce2b6a1367903406e6',1,'GrafikaProj::MainWindow']]]
];
