var searchData=
[
  ['endpoint',['endPoint',['../class_grafika_proj_1_1_main_window.html#a18572e2c995fd57f4d10443aa479f444',1,'GrafikaProj::MainWindow']]]
];
