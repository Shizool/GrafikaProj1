var searchData=
[
  ['resetposition',['ResetPosition',['../class_grafika_proj_1_1_main_window.html#a73bef7d10440a963f0e15a972dcbe941',1,'GrafikaProj::MainWindow']]]
];
