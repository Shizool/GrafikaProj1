var searchData=
[
  ['chartwindow',['ChartWindow',['../class_grafika_proj_1_1_chart_window.html',1,'GrafikaProj.ChartWindow'],['../class_grafika_proj_1_1_chart_window.html#ac696df976fa315b77d06a27d54319ff0',1,'GrafikaProj.ChartWindow.ChartWindow()'],['../class_grafika_proj_1_1_main_window.html#a540f54fa7bfa520e1ba83e97670c362b',1,'GrafikaProj.MainWindow.chartWindow()']]],
  ['chartwindow_2examl_2ecs',['ChartWindow.xaml.cs',['../_chart_window_8xaml_8cs.html',1,'']]],
  ['closingbymainwindow',['ClosingByMainWindow',['../class_grafika_proj_1_1_chart_window.html#a5f0b6593f705758e86402373f75fb0bf',1,'GrafikaProj::ChartWindow']]],
  ['contrast_5fvaluechanged',['Contrast_ValueChanged',['../class_grafika_proj_1_1_main_window.html#a994f218057b535a3f002eb42fca0ecd0',1,'GrafikaProj::MainWindow']]],
  ['contrastmap',['contrastMap',['../class_grafika_proj_1_1_image_customizator.html#a0ba86bb8684bc99b197ebd3346f532db',1,'GrafikaProj::ImageCustomizator']]]
];
