var searchData=
[
  ['gamma_5fvaluechanged',['Gamma_ValueChanged',['../class_grafika_proj_1_1_main_window.html#a3e949c359663048bc3d28baab78111f0',1,'GrafikaProj::MainWindow']]],
  ['gammamap',['gammaMap',['../class_grafika_proj_1_1_image_customizator.html#a5e36e80e5d2060ad43ada320af49954c',1,'GrafikaProj::ImageCustomizator']]],
  ['getcustomizedsource',['GetCustomizedSource',['../class_grafika_proj_1_1_image_customizator.html#a0935fd403698af0ed5cd681564f32a23',1,'GrafikaProj::ImageCustomizator']]],
  ['grafikaproj',['GrafikaProj',['../namespace_grafika_proj.html',1,'']]]
];
