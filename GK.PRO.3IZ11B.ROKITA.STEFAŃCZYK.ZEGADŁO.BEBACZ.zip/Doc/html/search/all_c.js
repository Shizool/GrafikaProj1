var searchData=
[
  ['saveclick',['SaveClick',['../class_grafika_proj_1_1_main_window.html#a204574e641ee3b1b06fcfbb3be4aca90',1,'GrafikaProj::MainWindow']]],
  ['setbrightness',['SetBrightness',['../class_grafika_proj_1_1_image_customizator.html#ae3ae615f9b76e92d94966c79415739ec',1,'GrafikaProj::ImageCustomizator']]],
  ['setcontrast',['SetContrast',['../class_grafika_proj_1_1_image_customizator.html#ada6a76ab7246497018fe73209872ac04',1,'GrafikaProj::ImageCustomizator']]],
  ['setgamma',['SetGamma',['../class_grafika_proj_1_1_image_customizator.html#a44ab9163ee2729921866ded0fdc2db01',1,'GrafikaProj::ImageCustomizator']]],
  ['setsource',['SetSource',['../class_grafika_proj_1_1_image_customizator.html#a5d95b9b8b484b02d0ca52bbbabb80511',1,'GrafikaProj::ImageCustomizator']]],
  ['startmargin',['startMargin',['../class_grafika_proj_1_1_main_window.html#a41a4fdf85f2929739a00381022cfd252',1,'GrafikaProj::MainWindow']]],
  ['startpoint',['startPoint',['../class_grafika_proj_1_1_main_window.html#a8f69f3a3c8a976ea669d2cbbeff7acfa',1,'GrafikaProj::MainWindow']]]
];
