var searchData=
[
  ['chartwindow',['ChartWindow',['../class_grafika_proj_1_1_chart_window.html#ac696df976fa315b77d06a27d54319ff0',1,'GrafikaProj::ChartWindow']]],
  ['contrast_5fvaluechanged',['Contrast_ValueChanged',['../class_grafika_proj_1_1_main_window.html#a994f218057b535a3f002eb42fca0ecd0',1,'GrafikaProj::MainWindow']]]
];
