var searchData=
[
  ['imagecustomizator',['ImageCustomizator',['../class_grafika_proj_1_1_image_customizator.html',1,'GrafikaProj']]]
];
