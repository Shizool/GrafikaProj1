var searchData=
[
  ['onclosing',['OnClosing',['../class_grafika_proj_1_1_chart_window.html#a300bce704ffe7ac5d1e03e9ce8d3de75',1,'GrafikaProj.ChartWindow.OnClosing()'],['../class_grafika_proj_1_1_main_window.html#a1575c0a51eae92482a7d3aa69f88058a',1,'GrafikaProj.MainWindow.OnClosing()']]]
];
