var searchData=
[
  ['isselecting',['IsSelecting',['../class_grafika_proj_1_1_main_window.html#a17347592f302b3ce2b6a1367903406e6',1,'GrafikaProj::MainWindow']]]
];
