var searchData=
[
  ['lineseries',['LineSeries',['../_chart_window_8xaml_8cs.html#abc0f3aa5ac1426e6efed5f1fe467018b',1,'ChartWindow.xaml.cs']]],
  ['loaderclick',['LoaderClick',['../class_grafika_proj_1_1_main_window.html#a987805e1fd3b72da6a64a0134944a2bd',1,'GrafikaProj::MainWindow']]]
];
